package com.example.custombarcharts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

class BarchartTestApi extends StatefulWidget {
  const BarchartTestApi({super.key});

  @override
  State<BarchartTestApi> createState() => _BarchartTestApiState();
}

class _BarchartTestApiState extends State<BarchartTestApi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Container()),
    );
  }
}